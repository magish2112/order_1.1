# 🗄️ Миграция на PostgreSQL для продакшена

Этот документ описывает процесс перехода с SQLite на PostgreSQL для продакшена.

## 📋 Обзор изменений

### Что изменилось:

1. **Схема Prisma** (`apps/api/prisma/schema.prisma`)
   - Изменен `provider` с `sqlite` на `postgresql`
   - JSON поля теперь используют нативный тип `Json` вместо `String`
   - Все связи и индексы оптимизированы для PostgreSQL

2. **Docker Compose** (`docker-compose.yml`)
   - API теперь использует PostgreSQL вместо SQLite
   - Добавлены зависимости от PostgreSQL контейнера
   - Удален volume для SQLite базы данных

3. **Утилиты JSON** (`apps/api/src/utils/json-fields.ts`)
   - Обновлены для работы с обоими типами БД
   - Автоматическое определение типа БД по `DATABASE_URL`

4. **Сервисы**
   - Все сервисы обновлены для работы с PostgreSQL
   - Комментарии обновлены для ясности

## 🚀 Быстрый старт с PostgreSQL

### 1. Настройка переменных окружения

Создайте файл `.env` в корне проекта:

```env
# PostgreSQL настройки
POSTGRES_DB=order_db
POSTGRES_USER=postgres
POSTGRES_PASSWORD=your_secure_password_here
POSTGRES_PORT=5432

# DATABASE_URL для API
DATABASE_URL=postgresql://postgres:your_secure_password_here@postgres:5432/order_db

# JWT секреты (обязательно измените!)
JWT_SECRET=your-jwt-secret-minimum-32-characters-long
JWT_REFRESH_SECRET=your-refresh-secret-minimum-32-characters-long

# CORS (укажите ваши домены)
CORS_ORIGIN=https://yourdomain.com,https://admin.yourdomain.com
```

### 2. Создание миграций PostgreSQL

```bash
cd apps/api

# Убедитесь, что DATABASE_URL указывает на PostgreSQL
export DATABASE_URL="postgresql://postgres:your_password@localhost:5432/order_db"

# Создайте миграцию
npx prisma migrate dev --name init_postgresql

# Или для продакшена (без интерактивного режима)
npx prisma migrate deploy
```

### 3. Запуск с Docker Compose

```bash
# Запуск всех сервисов
docker compose up -d --build

# Проверка статуса
docker compose ps

# Просмотр логов
docker compose logs -f api
```

## 🔄 Миграция данных из SQLite в PostgreSQL

Если у вас уже есть данные в SQLite, выполните следующие шаги:

### Вариант 1: Экспорт/Импорт через Prisma Studio

1. **Экспорт из SQLite:**
   ```bash
   # Запустите Prisma Studio с SQLite
   DATABASE_URL="file:./dev.db" npx prisma studio
   ```
   Экспортируйте данные вручную через интерфейс.

2. **Импорт в PostgreSQL:**
   ```bash
   # Запустите Prisma Studio с PostgreSQL
   DATABASE_URL="postgresql://..." npx prisma studio
   ```
   Импортируйте данные через интерфейс.

### Вариант 2: Использование скрипта миграции

Создайте скрипт `migrate-sqlite-to-postgres.ts`:

```typescript
import { PrismaClient as SQLiteClient } from '@prisma/client';
import { PrismaClient as PostgresClient } from '@prisma/client';

const sqliteClient = new SQLiteClient({
  datasources: { db: { url: 'file:./dev.db' } }
});

const postgresClient = new PostgresClient({
  datasources: { db: { url: process.env.DATABASE_URL } }
});

async function migrate() {
  // Миграция пользователей
  const users = await sqliteClient.user.findMany();
  for (const user of users) {
    await postgresClient.user.upsert({
      where: { email: user.email },
      update: user,
      create: user,
    });
  }
  
  // Аналогично для других таблиц...
  
  console.log('Миграция завершена!');
}

migrate();
```

## 📊 Различия между SQLite и PostgreSQL

### JSON поля

**SQLite:**
- JSON хранится как `TEXT` (строка)
- Требуется парсинг через `JSON.parse()`
- Сериализация через `JSON.stringify()`

**PostgreSQL:**
- JSON хранится как нативный тип `JSONB`
- Автоматическая валидация JSON
- Поддержка индексов на JSON полях
- Более эффективные запросы

### Типы данных

- **ID**: В обоих случаях используется `String @default(cuid())`
- **Boolean**: Работает одинаково
- **DateTime**: Работает одинаково
- **Float**: Работает одинаково
- **String**: Работает одинаково

### Производительность

PostgreSQL превосходит SQLite по:
- Конкурентному доступу (множественные запросы одновременно)
- Масштабируемости (большие объемы данных)
- Индексации (более эффективные индексы)
- Репликации (высокая доступность)

## 🛠️ Устранение проблем

### Ошибка подключения к PostgreSQL

```bash
# Проверьте, что PostgreSQL запущен
docker compose ps postgres

# Проверьте логи
docker compose logs postgres

# Проверьте подключение вручную
docker compose exec postgres psql -U postgres -d order_db
```

### Ошибка миграций

```bash
# Сброс миграций (ОСТОРОЖНО: удалит все данные!)
npx prisma migrate reset

# Применение миграций заново
npx prisma migrate deploy
```

### Проблемы с JSON полями

Если возникают ошибки с JSON полями:

1. Убедитесь, что используется правильная схема Prisma
2. Перегенерируйте Prisma Client:
   ```bash
   npx prisma generate
   ```
3. Проверьте, что данные корректно сериализуются

## 🔐 Безопасность для продакшена

1. **Сильные пароли:**
   - Используйте сложные пароли для PostgreSQL
   - Минимум 32 символа для JWT секретов

2. **Ограничение доступа:**
   - Не открывайте порт PostgreSQL наружу
   - Используйте firewall
   - Настройте SSL для подключений

3. **Резервное копирование:**
   ```bash
   # Создание бэкапа
   docker compose exec postgres pg_dump -U postgres order_db > backup.sql
   
   # Восстановление
   docker compose exec -T postgres psql -U postgres order_db < backup.sql
   ```

## 📝 Чеклист для деплоя

- [ ] Обновлен `DATABASE_URL` на PostgreSQL
- [ ] Созданы миграции PostgreSQL
- [ ] Применены миграции (`prisma migrate deploy`)
- [ ] Обновлены пароли и секреты
- [ ] Настроено резервное копирование
- [ ] Протестировано подключение к БД
- [ ] Проверена работа всех API endpoints
- [ ] Настроен мониторинг БД

## 🔗 Дополнительные ресурсы

- [Документация Prisma PostgreSQL](https://www.prisma.io/docs/concepts/database-connectors/postgresql)
- [Документация PostgreSQL](https://www.postgresql.org/docs/)
- [Docker Compose PostgreSQL](https://hub.docker.com/_/postgres)

