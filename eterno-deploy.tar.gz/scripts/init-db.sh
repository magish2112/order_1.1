#!/bin/sh
# Скрипт инициализации базы данных

set -e

echo "🔄 Ожидание готовности PostgreSQL..."
until pg_isready -h postgres -U postgres; do
  sleep 1
done

echo "📦 Выполнение миграций Prisma..."
npx prisma migrate deploy

echo "🔧 Генерация Prisma Client..."
npx prisma generate

echo "🌱 Заполнение базы данных тестовыми данными (опционально)..."
if [ "$SEED_DB" = "true" ]; then
  npm run prisma:seed
  echo "✅ База данных заполнена тестовыми данными"
else
  echo "⏭️  Пропуск заполнения базы данных (установите SEED_DB=true для заполнения)"
fi

echo "✅ Инициализация базы данных завершена!"

