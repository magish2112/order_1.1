# 🚀 Деплой проекта Eterno

**Дата:** 2026-01-26  
**Статус:** ✅ Готов к запуску

---

## ✅ ЧТО ГОТОВО

1. ✅ **Все ненужные README удалены** (оставлено 5 важных)
2. ✅ **.env файл создан** с автоматически сгенерированными секретами
3. ✅ **SECRETS.txt создан** - список всех секретов для сохранения
4. ✅ **Код оптимизирован** - готов к production

**Секреты сгенерированы:**
- JWT_SECRET: ✅
- JWT_REFRESH_SECRET: ✅  
- POSTGRES_PASSWORD: ✅

---

## 📝 ЧТО НУЖНО ЗАПИСАТЬ (для production)

### ОБЯЗАТЕЛЬНО сохраните эти данные:

```
JWT_SECRET=qozH/xlNXnc8JXUP7B+HXt1W5WnSjBzX4s3+SpsHtA4=
JWT_REFRESH_SECRET=bJBF3Iy0wgHGGprJ0QqsLVdOBbUFb3NtoE4GO7a4Cg0=
POSTGRES_PASSWORD=z10bZTLLrvhFRH1AOvDZ9pTtE8KrDTZP
```

**⚠️ Храните эти секреты в безопасном месте!**
- Password Manager (1Password, LastPass, Bitwarden)
- Зашифрованный файл
- Защищенное хранилище

**❌ НЕ КОММИТЬТЕ** файл SECRETS.txt в Git!

---

## 📋 ДЛЯ PRODUCTION (когда будете деплоить на сервер)

Замените в .env файле:

### 1. Домены (замените localhost):
```bash
CORS_ORIGIN=https://ваш-домен.ru,https://admin.ваш-домен.ru
NEXT_PUBLIC_API_URL=https://ваш-домен.ru
ADMIN_URL=https://admin.ваш-домен.ru
NEXT_PUBLIC_SITE_URL=https://ваш-домен.ru
SWAGGER_HOST=ваш-домен.ru
SWAGGER_SCHEME=https
```

### 2. SMTP (для email уведомлений):
```bash
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=ваш-email@gmail.com
SMTP_PASS=ваш-пароль-приложения
SMTP_FROM=noreply@ваш-домен.ru
```

---

## 🚀 ЗАПУСК (сейчас)

### Шаг 1: Запустите Docker Desktop

```powershell
# Запустите Docker Desktop вручную или:
Start-Process "C:\Program Files\Docker\Docker\Docker Desktop.exe"

# Подождите 30-60 секунд пока Docker запустится
```

### Шаг 2: Запустите проект

```powershell
cd c:\projects\eterno

# Остановить старые контейнеры (если есть)
docker compose down

# Запустить с Nginx
docker compose build
docker compose up -d

# Проверить статус
docker compose ps
```

### Шаг 3: Проверьте работу

```powershell
# Health check API
curl http://localhost/health

# Откройте в браузере
start http://localhost          # Главный сайт
start http://localhost:3001     # Админка
```

### Шаг 4: Создайте первого админа

```powershell
# Запустить миграции
docker compose exec api npx prisma migrate deploy

# Создать админа
docker compose exec api node create-admin-eterno.js
```

---

## 📊 Проверка результатов

После запуска проверьте:

1. **Главный сайт:** http://localhost
2. **API:** http://localhost/api/v1/settings/public
3. **Health:** http://localhost/health
4. **Админка:** http://localhost:3001

**Должно работать:**
- ✅ Nginx раздает статику
- ✅ API отвечает
- ✅ Web сайт загружается
- ✅ Админка доступна

---

## 📁 Оставлены документы

Удалено 13 лишних файлов. Оставлено **5 важных**:

1. **START_HERE.md** - Начните отсюда
2. **PRODUCTION_READY.md** - Быстрый старт
3. **PRODUCTION_DEPLOYMENT_CHECKLIST.md** - Полный чеклист
4. **SECURITY_AUDIT.md** - Security
5. **OPTIMIZATION_SUMMARY.md** - Результаты оптимизации

---

## 🔧 Полезные команды

```powershell
# Логи всех сервисов
docker compose logs -f

# Логи конкретного сервиса
docker compose logs -f api
docker compose logs -f nginx

# Перезапустить сервис
docker compose restart api

# Остановить все
docker compose down

# Статус
docker compose ps
```

---

## ⚠️ ВАЖНО

### Текущая конфигурация (localhost):

Сейчас проект настроен для **локального запуска**:
- CORS: localhost
- URLs: http://localhost
- Без SSL

### Для production деплоя:

1. Замените localhost на реальные домены
2. Получите SSL сертификаты (Let's Encrypt)
3. Обновите nginx.conf для HTTPS
4. Настройте SMTP
5. Используйте docker-compose.production.yml

---

## 🎉 Готово!

**Что сделано:**
- ✅ Секреты сгенерированы
- ✅ .env создан
- ✅ Лишние файлы удалены
- ✅ Проект готов к запуску

**Следующий шаг:**
1. Запустите Docker Desktop
2. Выполните команды из раздела "ЗАПУСК"
3. Проверьте http://localhost

---

**Если возникнут вопросы - читайте START_HERE.md** 📚
