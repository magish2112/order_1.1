#!/bin/bash

# Скрипт для настройки SQLite базы данных

echo "🔄 Настройка SQLite базы данных..."

# Удаляем старую папку миграций PostgreSQL
if [ -d "prisma/migrations" ]; then
    echo "📦 Удаляем старые миграции PostgreSQL..."
    rm -rf prisma/migrations
fi

# Удаляем старую базу данных (если есть)
if [ -f "dev.db" ]; then
    echo "🗑️  Удаляем старую базу dev.db..."
    rm dev.db
fi

if [ -f "production.db" ]; then
    echo "🗑️  Удаляем старую базу production.db..."
    rm production.db
fi

# Создаем новые миграции для SQLite
echo "🔨 Создание новых миграций для SQLite..."
npx prisma migrate dev --name init_sqlite

# Генерируем Prisma Client
echo "⚙️  Генерация Prisma Client..."
npx prisma generate

# Заполняем базу начальными данными
echo "🌱 Заполнение базы данных..."
npm run prisma:seed

echo "✅ SQLite база данных настроена!"
echo ""
echo "📊 База данных создана: dev.db"
echo "👤 Администратор: admin@example.com / admin123"
echo ""
echo "🚀 Запустите сервер: npm run dev"
