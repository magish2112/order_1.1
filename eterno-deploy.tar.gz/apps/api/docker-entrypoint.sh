#!/bin/sh
set -e

# Переходим в рабочую директорию приложения
cd /app || exit 1

# Проверяем тип базы данных
if echo "$DATABASE_URL" | grep -q "file:"; then
  echo "🗄️ Используется SQLite база данных (режим разработки)"
  # Создаем директорию для SQLite базы данных, если она не существует
  DB_FULL_PATH=$(echo "$DATABASE_URL" | sed 's|file:||')
  DB_DIR=$(dirname "$DB_FULL_PATH")
  if [ -n "$DB_DIR" ] && [ "$DB_DIR" != "." ]; then
    mkdir -p "$DB_DIR" 2>/dev/null || true
    echo "✅ Директория для базы данных создана: $DB_DIR"
  fi
else
  echo "🔄 Ожидание готовности PostgreSQL..."
  # Извлекаем хост из DATABASE_URL
  DB_HOST=$(echo "$DATABASE_URL" | sed -n 's/.*@\([^:]*\):.*/\1/p')
  DB_USER=$(echo "$DATABASE_URL" | sed -n 's/.*:\/\/\([^:]*\):.*/\1/p')
  
  # Используем переменные окружения или значения из DATABASE_URL
  POSTGRES_HOST=${DB_HOST:-postgres}
  POSTGRES_USER=${DB_USER:-${POSTGRES_USER:-postgres}}
  
  echo "Подключение к PostgreSQL: $POSTGRES_HOST как $POSTGRES_USER"
  
  # Ждем готовности PostgreSQL
  until pg_isready -h "$POSTGRES_HOST" -U "$POSTGRES_USER" > /dev/null 2>&1; do
    echo "⏳ Ожидание PostgreSQL на $POSTGRES_HOST..."
    sleep 2
  done
  echo "✅ PostgreSQL готов!"
fi

echo "📦 Выполнение миграций Prisma..."
npx prisma migrate deploy || true

echo "🔧 Генерация Prisma Client..."
npx prisma generate

echo "🌱 Заполнение базы данных тестовыми данными (если нужно)..."
npx prisma db seed || echo "⚠️ Seed не выполнен (возможно, данные уже есть)"

echo "🚀 Запуск API сервера..."
exec node dist/server.js

