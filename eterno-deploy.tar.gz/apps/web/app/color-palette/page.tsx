import { ColorPaletteShowcase } from '@/components/ui/color-palette-showcase'

export default function ColorPalettePage() {
  return <ColorPaletteShowcase />
}

