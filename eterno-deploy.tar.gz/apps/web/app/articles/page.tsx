import { redirect } from 'next/navigation'

export default function ArticlesRedirectPage() {
  redirect('/stati')
}
