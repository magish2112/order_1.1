import { redirect } from 'next/navigation'

export default function VacanciesRedirectPage() {
  redirect('/vakansii')
}
