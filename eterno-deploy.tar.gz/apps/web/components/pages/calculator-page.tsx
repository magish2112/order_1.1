'use client'

export { Calculator as CalculatorPage } from '@/components/sections/calculator'

