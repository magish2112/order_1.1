# Сайт ремонтно-строительной компании

Полнофункциональный корпоративный сайт с административной панелью для управления контентом.

## 🏗️ Архитектура проекта

Проект состоит из трех основных приложений:

- **Web** (`apps/web`) - Публичный сайт на Next.js 14
- **Admin** (`apps/admin`) - Административная панель на React + Vite
- **API** (`apps/api`) - Backend API на Fastify + TypeScript

## 🚀 Быстрый старт с Docker

### Предварительные требования

- Docker Engine и плагин Compose (`docker compose`). На Linux: `sudo apt-get install docker-compose-plugin`. На старых системах с `docker-compose` (V1) используйте `./scripts/compose.sh` — обходит ошибку `ContainerConfig`.
- Git

### 1. Клонирование репозитория

```bash
git clone https://github.com/magish2112/order_1.1.git
cd order_1.1
```

### 2. Настройка переменных окружения

Создайте файл `.env` в корне проекта на основе `.env.example`:

```bash
cp .env.example .env
```

Отредактируйте `.env` и установите необходимые значения, особенно:
- `JWT_SECRET` - секретный ключ для JWT (минимум 32 символа)
- `JWT_REFRESH_SECRET` - секретный ключ для refresh токенов (минимум 32 символа)
- `POSTGRES_PASSWORD` - пароль для PostgreSQL

### 3. Запуск проекта

```bash
# Сборка и запуск всех сервисов
docker compose up -d --build

# Просмотр логов
docker compose logs -f

# Остановка всех сервисов
docker compose down
```

На системах только с `docker-compose` (V1) вместо `docker compose` используйте `./scripts/compose.sh` (напр. `./scripts/compose.sh up -d --build`), чтобы обойти ошибку `ContainerConfig`.

### 4. Инициализация базы данных

После первого запуска миграции выполняются автоматически через entrypoint скрипт. Если нужно заполнить базу тестовыми данными:

```bash
# Заполнение базы тестовыми данными (опционально)
docker compose exec api npm run prisma:seed
```

**Примечание**: Миграции Prisma выполняются автоматически при запуске контейнера API.

### 5. Доступ к приложениям

После успешного запуска приложения будут доступны по следующим адресам:

- **Публичный сайт**: http://localhost:3000
- **Админ-панель**: http://localhost:3001
- **API**: http://localhost:4000
- **API документация**: http://localhost:4000/api/docs
- **MinIO Console**: http://localhost:9001 (minioadmin/minioadmin)

## 📋 Управление Docker контейнерами

```bash
# Просмотр статуса контейнеров
docker compose ps

# Просмотр логов конкретного сервиса
docker compose logs -f api
docker compose logs -f web
docker compose logs -f admin

# Перезапуск конкретного сервиса
docker compose restart api

# Остановка всех сервисов
docker compose down

# Остановка с удалением volumes (удалит все данные!)
docker compose down -v

# Пересборка конкретного сервиса
docker compose build api
docker compose up -d api

# Пересборка Web (нужна после смены NEXT_PUBLIC_API_URL в .env)
docker compose build --no-cache web && docker compose up -d web

# Пересборка Admin (нужна после смены VITE_API_URL в .env). Для production — на сервере по SSH:
#   bash scripts/setup-admin-production.sh 46.17.102.76
# (добавит VITE_API_URL в .env, пересоберёт API и admin, сгенерирует пароль, выведет данные для входа)

# Если order_web в статусе Exited (137) или сайт не отдаёт ответ — поднять заново:
./scripts/compose.sh up -d web
# при повторных падениях: docker compose build --no-cache web && ./scripts/compose.sh up -d web
```

## 🔧 Разработка

Для разработки используйте `docker-compose.dev.yml`:

```bash
# Запуск в режиме разработки (с hot-reload)
docker compose -f docker-compose.yml -f docker-compose.dev.yml up

# Или только база данных и Redis
docker compose up -d postgres redis minio

# Затем запускайте приложения локально
cd apps/api && npm run dev
cd apps/web && npm run dev
cd apps/admin && npm run dev
```

## 🗄️ База данных

### Подключение к PostgreSQL

```bash
# Через Docker
docker compose exec postgres psql -U postgres -d order_db

# Или используя внешний клиент
# Host: localhost
# Port: 5432
# Database: order_db
# User: postgres
# Password: (из .env файла)
```

### Prisma команды

```bash
# Выполнение миграций (для продакшена)
docker compose exec api npx prisma migrate deploy

# Создание новой миграции (в режиме разработки)
docker compose exec api npx prisma migrate dev --name migration_name

# Prisma Studio (GUI для базы данных)
docker compose exec api npx prisma studio
# Откроется на http://localhost:5555
```

### Резервное копирование PostgreSQL

```bash
# Создание бэкапа
docker compose exec postgres pg_dump -U postgres order_db > backup_$(date +%Y%m%d_%H%M%S).sql

# Восстановление из бэкапа
docker compose exec -T postgres psql -U postgres order_db < backup.sql

# Автоматическое резервное копирование (рекомендуется настроить через cron)
```

## 📦 Структура проекта

```
order_1.1/
├── apps/
│   ├── api/          # Backend API (Fastify)
│   ├── web/          # Публичный сайт (Next.js)
│   └── admin/        # Админ-панель (React + Vite)
├── scripts/
│   ├── compose.sh                 # Обёртка: docker compose или docker-compose + workaround ContainerConfig
│   ├── init-db.sh
│   ├── setup-admin-production.sh  # На сервере: настройка админки (VITE_API_URL, пароль, пересборка)
│   └── RUN_ON_SERVER.md           # Пошаговые команды для выполнения на сервере по SSH
├── docker-compose.yml
├── docker-compose.dev.yml
├── .env.example
└── README.md
```

## 🔐 Первый вход в админ-панель

После запуска проекта и заполнения базы данных:

1. Откройте http://localhost:3001
2. Войдите с учетными данными, созданными в seed скрипте
3. По умолчанию создается пользователь:
   - Email: `admin@example.com`
   - Password: `admin123` (измените после первого входа!)

## 🛠️ Устранение неполадок

### Ошибка `KeyError: 'ContainerConfig'` (docker-compose 1.29.x)

При `up -d` или `up -d web` на старом **docker-compose** (V1) может возникать `KeyError: 'ContainerConfig'`. Это известный баг, в V1 не исправляется.

**Рекомендуемое решение — перейти на Compose V2:**

```bash
# Ubuntu/Debian
sudo apt-get update && sudo apt-get install docker-compose-plugin

# Проверка
docker compose version
```

После установки используйте `docker compose` вместо `docker-compose` (в документации проекта — уже `docker compose`).

**Временный обход без переустановки:** используйте скрипт-обёртку, который перед `up` удаляет существующие контейнеры и избегает пути «recreate»:

```bash
./scripts/compose.sh up -d web
./scripts/compose.sh up -d api
```

Скрипт сам выбирает `docker compose` (если есть) или `docker-compose` с workaround. На Linux перед первым запуском: `chmod +x scripts/compose.sh`.

### Проблемы с портами

Если порты заняты, измените их в `.env` файле:
```env
WEB_PORT=3000
ADMIN_PORT=3001
API_PORT=4000
POSTGRES_PORT=5432
```

### Очистка и пересборка

```bash
# Остановка и удаление контейнеров
docker compose down

# Удаление volumes (удалит все данные БД!)
docker compose down -v

# Пересборка без кеша
docker compose build --no-cache

# Запуск заново
docker compose up -d
```

### Проблемы с Prisma

```bash
# Перегенерация Prisma Client
docker compose exec api npx prisma generate

# Сброс базы данных (ОСТОРОЖНО: удалит все данные!)
docker compose exec api npx prisma migrate reset
```

### Просмотр логов

```bash
# Все логи
docker compose logs

# Логи конкретного сервиса
docker compose logs api
docker compose logs web
docker compose logs postgres

# Логи в реальном времени
docker compose logs -f api
```

## 📝 Переменные окружения

Основные переменные окружения описаны в `.env.example`. Обязательные переменные:

- `JWT_SECRET` - секретный ключ для JWT (минимум 32 символа)
- `JWT_REFRESH_SECRET` - секретный ключ для refresh токенов (минимум 32 символа)
- `DATABASE_URL` - URL подключения к PostgreSQL
- `POSTGRES_PASSWORD` - пароль для PostgreSQL

## 🚢 Деплой

Для продакшн деплоя:

1. Обновите переменные окружения в `.env` в **корне проекта** (см. [ENV_EXAMPLE.md](./ENV_EXAMPLE.md)):
   - `CORS_ORIGIN` — origins сайта и админки (напр. `http://46.17.102.76:3000,http://46.17.102.76:3001`)
   - `NEXT_PUBLIC_API_URL` — URL API для браузера (напр. `http://46.17.102.76:4000`). После смены нужна пересборка:  
     `docker compose build --no-cache web && ./scripts/compose.sh up -d web`
2. Настройте SSL (Nginx и т.п.) при использовании домена
3. **На сервере по SSH** (в каталоге с проектом) настройте админ-панель и пароль администратора:
   ```bash
   bash scripts/setup-admin-production.sh 46.17.102.76
   ```
   Скрипт добавит `VITE_API_URL` в `.env`, пересоберёт API и admin, сгенерирует пароль и выведет данные для входа (`admineterno@yandex.ru`). Сохраните пароль.  
   **Пошагово с копируемыми командами:** [scripts/RUN_ON_SERVER.md](./scripts/RUN_ON_SERVER.md).  
   Вручную: [apps/api/DEPLOY.md](./apps/api/DEPLOY.md), [ENV_EXAMPLE.md](./ENV_EXAMPLE.md) п.5.

## 📚 Дополнительная документация

- [Техническое задание](./TECHNICAL_SPECIFICATION.md)
- [Инструкции по деплою](./apps/api/DEPLOY.md)
- [Миграция на PostgreSQL](./POSTGRESQL_MIGRATION.md)

## 📄 Лицензия

Проект разработан для ремонтно-строительной компании.

## 👥 Контакты

GitHub: [@magish2112](https://github.com/magish2112)

